package common

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.slf4j.LoggerFactory

//Case class used to create empty data frame used in case of exception
case class Empty(id: Int)

object SparkCommon {
  private val logger = LoggerFactory.getLogger(getClass.getName)

  //Method that creates spark Session variable
  def createSparkSession(): Option[SparkSession] = {
    try {
      System.setProperty("hadoop.home.dir", "C:\\hadoop")
      val spark = SparkSession
        .builder
        .appName("Assignment")
        .config("spark.master", "local")
        //.config("spark.sql.warehouse.dir", <warehouseLocation>)
        .enableHiveSupport()
        .getOrCreate()
      logger.info("Spark Session Created")
      Some(spark)
    } catch {
      case e: Exception =>
        logger.error("An exception in creating Session" + e.printStackTrace())
        System.exit(1)
        None
    }
  }

    //Method that writes data to hive table
    def writeToHiveTable(spark: SparkSession, df: DataFrame,hiveTable: String): Unit = {
    try {
      val hiveTableView = hiveTable + "_View"
      logger.warn("Hive View:::" + hiveTableView)
      df.createGlobalTempView(hiveTableView)
      //spark.sql("select * from global_temp." + hiveTableView ).show()
      df.write.mode(SaveMode.Append).insertInto("assignment." + hiveTable)
      spark.catalog.dropGlobalTempView(hiveTableView)
    } catch {
    case e: Exception =>
      logger.error("Error occurred in writeToHiveTable " + e.printStackTrace())
      System.exit(1)
    }

    }

  //Method to create hive tables
  def createHiveTable(spark: SparkSession):Unit = {
    try {
      logger.info("Creating Database in Hive")
      spark.sql("create database if not exists Assignment")
      spark.sql("create table if not exists Assignment.tbl_raw_temperature(" +
        "recorded_year int,recorded_month int,recorded_day int" +
        ",morning_temp double, noon_temp double, night_temp double" +
        ",min_temp double, max_temp double,recorded_date date)" +
        "stored as parquet")
      //" row format delimited fields terminated by ',' lines terminated by '\n' stored as textfile")
      //spark.sql("alter table Assignment.tbl_raw_temperature set tblproperties('serialization.null.format'='')")
      spark.sql("create table if not exists Assignment.tbl_barometer_temperature(" +
        "recorded_year int ,recorded_month int,recorded_day int" +
        ",reading_1 double , reading_2 double, reading_3 double,recorded_date date" +
        ") stored as parquet")
      //spark.sql("alter table Assignment.tbl_barometer_temperature set tblproperties('serialization.null.format'='')")

    } catch {
      case e: Exception =>
        logger.error("Error occurred while create Hive DataBase Object" + e.printStackTrace())
        System.exit(1)
    }
  }

    def createRawFilteredDataFrame(spark:SparkSession,inputDataFrame: DataFrame): DataFrame ={
      try{

        inputDataFrame.createGlobalTempView("temp_view")
        val filteredDF = spark.sql("SELECT * FROM global_temp.temp_view " +
            "where isNaN(morning) = false and isNaN(noon) = false and isNaN(night) = false" +
            " and isNaN(min) = false and isNaN(max) = false")
        spark.catalog.dropGlobalTempView("temp_view")
        filteredDF
      } catch {
        case e: Exception =>
          logger.error("Error occurred in createRawFilteredDataFrame: " + e.printStackTrace())
          System.exit(1)
          import spark.implicits._
          val emptyDF=Seq(("")).toDF("tracking_time")
          emptyDF.show()
          emptyDF
      }
    }

  def createBarometerFilteredDataFrame(spark:SparkSession,inputDataFrame: DataFrame): DataFrame ={
    try{
        inputDataFrame.createGlobalTempView("temp_view")
        val filteredDF = spark.sql("SELECT * FROM global_temp.temp_view " +
          "where isNaN(reading_1) = false and isNaN(reading_2) = false and isNaN(reading_3) = false")
        spark.catalog.dropGlobalTempView("temp_view")
        filteredDF

    } catch {
      case e: Exception =>
        logger.error("Error occurred in createBarometerFilteredDataFrame: " + e.printStackTrace())
        import spark.implicits._
        val emptyDF=Seq(("")).toDF("tracking_time")
        System.exit(1)
        emptyDF
    }
  }

}

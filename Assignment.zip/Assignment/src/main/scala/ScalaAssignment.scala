
import common.SparkCommon
import org.apache.spark.sql.functions.{col, concat_ws, lit, to_date}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.types.{DateType, DoubleType, IntegerType, StringType, StructType};

object ScalaAssignment {
  private val logger = LoggerFactory.getLogger(getClass.getName)
  private val RAW_TEMP_HIVE_TABLE = "tbl_raw_temperature"
  private val BAROMETER_TEMP_HIVE_TABLE = "tbl_barometer_temperature"
  //PRIVATE VAL RAW_TEMP_URL = "HTTPS://BOLIN.SU.SE/DATA/STOCKHOLM-THEMATIC/FILES/STOCKHOLM-HISTORICAL-WEATHER-OBSERVATIONS-2017/TEMPERATURE/DAILY/RAW/STOCKHOLM_DAILY_TEMP_OBS_1859_1960_T1T2T3TXTN.TXT"
  //private val BAROMETER_TEMP_RUL = "https://bolin.su.se/data/stockholm-thematic/files/stockholm-historical-weather-observations-2017/air_pressure/raw/stockholm_barometer_1938_1960.txt"
  def main(args: Array[String]): Unit = {
    try{

      //Create spark session

      logger.info("Main method Started")
      //Get spark session from Sparkcommon object
      val spark = SparkCommon.createSparkSession().get

      //File options
      val raw_temp_file="./data/raw_Temperature_DataSet.csv"
      val barometer_temp_file="./data/barometer_temperature_dataset.csv"

      //Load raw temperature data into Spark DataFrame
      val rawDF = spark.read.options(Map("inferSchema"->"true","delimiter"->",","header"->"true"))
          .csv(raw_temp_file)
      //Load barometer temperature data into Spark DataFra
      val barometerDF = spark.read.options(Map("inferSchema"->"true","delimiter"->",","header"->"true"))
        .csv(barometer_temp_file)

      //Generate date column from year, month and day columns present in data extract
      // and add it to new raw temperature data frame
      val withDateRawDF = rawDF.withColumn("recorded_date"
      ,concat_ws("-",col("year"), col("month"), col("day")))
      val toDateRawDF = withDateRawDF.withColumn("recorded_date",col("recorded_date").cast(DateType))

      //Generate date column from year, month and day columns present in data extract
      // and add it to new raw barometer data frame
      val withDateBarometerDF = barometerDF.withColumn("recorded_date"
        ,concat_ws("-",col("recorded_year"), col("recorded_month"), col("recorded_day")))
      val toDateBarometerDF = withDateBarometerDF.withColumn("recorded_date",col("recorded_date").cast(DateType))

      //Log messages for Debugging purpose
      logger.info("No of record read: " + toDateRawDF.count())
      logger.info("No of record read: " + toDateBarometerDF.count())

      //Filter rows that are not complete, some of the records have NaN which will be removed here
      val rawFilteredDF = SparkCommon.createRawFilteredDataFrame(spark,toDateRawDF);
      val barometerFilteredDF = SparkCommon.createBarometerFilteredDataFrame(spark,toDateBarometerDF);

      //Log messages for Debugging purpose
      logger.info("No of record read: " + rawFilteredDF.count)
      logger.info("No of record read: " + barometerFilteredDF.count)

      //Call to create hive tables
      SparkCommon.createHiveTable(spark);

      //If filtered dataframe has records to store in hive table, call method to load data to hive table
      if(rawFilteredDF.count > 1){
        SparkCommon.writeToHiveTable(spark,rawFilteredDF,RAW_TEMP_HIVE_TABLE)
      }
      if(barometerFilteredDF.count > 1){
        SparkCommon.writeToHiveTable(spark,barometerFilteredDF,BAROMETER_TEMP_HIVE_TABLE)
      }

      //Log messages for Debugging purpose
      logger.info("Program executed Successfully")

    } catch {
      case e: Exception =>
        logger.error("An error occurred in main method: " + e.printStackTrace())
    }
  }
}

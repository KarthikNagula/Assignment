import org.apache.spark.sql.SparkSession
import common.SparkCommon
import org.apache.spark.sql.catalyst.dsl.expressions.StringToAttributeConversionHelper
import org.apache.spark.sql.functions.{col, concat_ws, lit, to_date}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.types.{DateType, DoubleType, IntegerType, StringType, StructType};

object ScalaAssignment {
  private val logger = LoggerFactory.getLogger(getClass.getName)
  private val raw_temp_hive_table = "tbl_raw_temperature"
  private val barometer_temp_hive_table = "tbl_barometer_temperature"
  //private val raw_temp_url = "https://bolin.su.se/data/stockholm-thematic/files/stockholm-historical-weather-observations-2017/temperature/daily/raw/stockholm_daily_temp_obs_1859_1960_t1t2t3txtn.txt"
  //private val barometer_temp_rul = "https://bolin.su.se/data/stockholm-thematic/files/stockholm-historical-weather-observations-2017/air_pressure/raw/stockholm_barometer_1938_1960.txt"
  def main(args: Array[String]): Unit = {
    try{

      //Create spark session

      logger.info("Main method Started")
      val spark = SparkCommon.createSparkSession().get

      //File options
      val raw_temp_file="./data/raw_Temperature_DataSet.csv"
      val barometer_temp_file="./data/barometer_temperature_dataset.csv"
      /* val filetype = "csv"
      val delimiter  = ","
      val infer_Schema=true
      val first_row_is_header=true*/

      val rawDF = spark.read.options(Map("inferSchema"->"true","delimiter"->",","header"->"true"))
          .csv(raw_temp_file)
      val barometerDF = spark.read.options(Map("inferSchema"->"true","delimiter"->",","header"->"true"))
        .csv(barometer_temp_file)

      val withDateRawDF = rawDF.withColumn("recorded_date"
      ,concat_ws("-",col("year"), col("month"), col("day")))
      val toDateRawDF = withDateRawDF.withColumn("recorded_date",col("recorded_date").cast(DateType))
      //toDateRawDF.printSchema()

      val withDateBarometerDF = barometerDF.withColumn("recorded_date"
        ,concat_ws("-",col("recorded_year"), col("recorded_month"), col("recorded_day")))
      val toDateBarometerDF = withDateBarometerDF.withColumn("recorded_date",col("recorded_date").cast(DateType))
      //toDateBarometerDF.printSchema()

      logger.warn("No of record read: " + toDateRawDF.count())
      logger.warn("No of record read: " + toDateBarometerDF.count())

      val rawFilteredDF = SparkCommon.createRawFilteredDataFrame(spark,toDateRawDF);
      val barometerFilteredDF = SparkCommon.createBarometerFilteredDataFrame(spark,toDateBarometerDF);

      logger.warn("No of record read: " + rawFilteredDF.count)
      logger.warn("No of record read: " + barometerFilteredDF.count)

      SparkCommon.createHiveTable(spark);
      if(rawFilteredDF.count > 1){
        SparkCommon.writeToHiveTable(spark,rawFilteredDF,raw_temp_hive_table)
      }
      if(barometerFilteredDF.count > 1){
        SparkCommon.writeToHiveTable(spark,barometerFilteredDF,barometer_temp_hive_table)
      }


      logger.info("Program executed Successfully")
      logger.warn("Dummy Warning")
      logger.error("Dummy Error")

    } catch {
      case e: Exception =>
        logger.error("An error occurred in main method: " + e.printStackTrace())
    }
  }
}
